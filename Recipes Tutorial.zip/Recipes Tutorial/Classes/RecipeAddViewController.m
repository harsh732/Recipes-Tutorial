

#import "RecipeAddViewController.h"
#import "Recipe.h"

@interface RecipeAddViewController () <UITextFieldDelegate>

@property (nonatomic, strong) IBOutlet UITextField *nameTextField;

@end


#pragma mark -

@implementation RecipeAddViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
        
    // Configure the navigation bar
    self.navigationItem.title = @"Add Recipe";
    
	[self.nameTextField becomeFirstResponder];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    
	if (textField == self.nameTextField) {
		[self.nameTextField resignFirstResponder];
		[self save:self];
	}
	return YES;
}

- (IBAction)save:(id)sender {
    
    self.recipe.name = self.nameTextField.text;

	NSError *error = nil;
	if (![self.recipe.managedObjectContext save:&error]) {
		
		NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
		abort();
	}		
    
	[self.delegate recipeAddViewController:self didAddRecipe:self.recipe];
}

- (IBAction)cancel:(id)sender {
	
	[self.recipe.managedObjectContext deleteObject:self.recipe];

	NSError *error = nil;
	if (![self.recipe.managedObjectContext save:&error]) {
		
		NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
		abort();
	}		

    [self.delegate recipeAddViewController:self didAddRecipe:nil];
}

@end
