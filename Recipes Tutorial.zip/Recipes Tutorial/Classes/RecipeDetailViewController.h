

@class Recipe;

@interface RecipeDetailViewController : UITableViewController
            
@property (nonatomic, strong) Recipe *recipe;

@end
