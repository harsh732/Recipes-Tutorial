

#import "RecipePhotoViewController.h"
#import "Recipe.h"

@interface RecipePhotoViewController ()

@property(nonatomic, strong) UIImageView *imageView;

@end


#pragma mark -

@implementation RecipePhotoViewController

- (void)loadView {
    
	self.title = @"Photo";

    _imageView = [[UIImageView alloc] initWithFrame:[UIScreen mainScreen].applicationFrame];
    self.imageView.contentMode = UIViewContentModeScaleAspectFit;
    self.imageView.backgroundColor = [UIColor blackColor];
    
    self.view = self.imageView;
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    self.imageView.image = [self.recipe.image valueForKey:@"image"];
}

@end
