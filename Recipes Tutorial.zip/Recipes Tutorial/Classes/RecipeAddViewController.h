

@protocol RecipeAddDelegate;

@class Recipe;

@interface RecipeAddViewController : UIViewController

@property (nonatomic, strong) Recipe *recipe;
@property (nonatomic, unsafe_unretained) id <RecipeAddDelegate> delegate;

@end


#pragma mark -

@protocol RecipeAddDelegate <NSObject>

// recipe == nil on cancel
- (void)recipeAddViewController:(RecipeAddViewController *)recipeAddViewController didAddRecipe:(Recipe *)recipe;

@end
