

@class Recipe;

@interface RecipePhotoViewController : UIViewController

@property(nonatomic, strong) Recipe *recipe;

@end
