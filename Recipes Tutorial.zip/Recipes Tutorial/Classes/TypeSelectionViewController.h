

@class Recipe;

@interface TypeSelectionViewController : UITableViewController

@property (nonatomic, strong) Recipe *recipe;

@end
