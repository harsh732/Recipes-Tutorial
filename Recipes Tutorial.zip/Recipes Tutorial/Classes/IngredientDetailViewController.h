

@class Recipe, Ingredient;

@interface IngredientDetailViewController : UITableViewController

@property (nonatomic, strong) Recipe *recipe;
@property (nonatomic, strong) Ingredient *ingredient;

@end
