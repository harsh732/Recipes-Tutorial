

#import "Ingredient.h"
#import "Recipe.h"

@implementation Ingredient 

@dynamic name, amount, displayOrder, recipe;

@end
