

#import "RecipeTableViewCell.h"

@interface RecipeTableViewCell ()

@property (nonatomic, strong) UIImageView *recipeImageView;
@property (nonatomic, strong) UILabel *nameLabel;
@property (nonatomic, strong) UILabel *overviewLabel;
@property (nonatomic, strong) UILabel *prepTimeLabel;

- (CGRect)_imageViewFrame;
- (CGRect)_nameLabelFrame;
- (CGRect)_descriptionLabelFrame;
- (CGRect)_prepTimeLabelFrame;

@end


#pragma mark -

@implementation RecipeTableViewCell

- (id)initWithCoder:(NSCoder *)aDecoder {
    
	if (self = [super initWithCoder:aDecoder]) {
        _recipeImageView = [[UIImageView alloc] initWithFrame:CGRectZero];
		self.recipeImageView.contentMode = UIViewContentModeScaleAspectFit;
        [self.contentView addSubview:self.recipeImageView];
        
        _overviewLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        [self.overviewLabel setFont:[UIFont systemFontOfSize:12.0]];
        [self.overviewLabel setTextColor:[UIColor darkGrayColor]];
        [self.overviewLabel setHighlightedTextColor:[UIColor whiteColor]];
        [self.contentView addSubview:self.overviewLabel];
        
        _prepTimeLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        self.prepTimeLabel.textAlignment = NSTextAlignmentRight;
        [self.prepTimeLabel setFont:[UIFont systemFontOfSize:12.0]];
        [self.prepTimeLabel setTextColor:[UIColor blackColor]];
        [self.prepTimeLabel setHighlightedTextColor:[UIColor whiteColor]];
		self.prepTimeLabel.minimumScaleFactor = 7.0;
		self.prepTimeLabel.lineBreakMode = NSLineBreakByTruncatingTail;
        [self.contentView addSubview:self.prepTimeLabel];
        
        _nameLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        [self.nameLabel setFont:[UIFont boldSystemFontOfSize:14.0]];
        [self.nameLabel setTextColor:[UIColor blackColor]];
        [self.nameLabel setHighlightedTextColor:[UIColor whiteColor]];
        [self.contentView addSubview:self.nameLabel];
    }
    
    return self;
}

// to save space, the prep time label disappears during editing
- (void)layoutSubviews {
    
    [super layoutSubviews];
	
    [self.recipeImageView setFrame:[self _imageViewFrame]];
    [self.nameLabel setFrame:[self _nameLabelFrame]];
    [self.overviewLabel setFrame:[self _descriptionLabelFrame]];
    [self.prepTimeLabel setFrame:[self _prepTimeLabelFrame]];
    if (self.editing) {
        self.prepTimeLabel.alpha = 0.0;
    } else {
        self.prepTimeLabel.alpha = 1.0;
    }
}


#define IMAGE_SIZE          42.0
#define EDITING_INSET       10.0
#define TEXT_LEFT_MARGIN    8.0
#define TEXT_RIGHT_MARGIN   5.0
#define PREP_TIME_WIDTH     80.0

// returns the frame of the various subviews -- these are dependent on the editing state of the cell
- (CGRect)_imageViewFrame {
    
    if (self.editing) {
        return CGRectMake(EDITING_INSET, 0.0, IMAGE_SIZE, IMAGE_SIZE);
    }
	else {
        return CGRectMake(0.0, 0.0, IMAGE_SIZE, IMAGE_SIZE);
    }
}

- (CGRect)_nameLabelFrame {
    
    if (self.editing) {
        return CGRectMake(IMAGE_SIZE + EDITING_INSET + TEXT_LEFT_MARGIN, 4.0, self.contentView.bounds.size.width - IMAGE_SIZE - EDITING_INSET - TEXT_LEFT_MARGIN, 16.0);
    }
	else {
        return CGRectMake(IMAGE_SIZE + TEXT_LEFT_MARGIN, 4.0, self.contentView.bounds.size.width - IMAGE_SIZE - TEXT_RIGHT_MARGIN * 2 - PREP_TIME_WIDTH, 16.0);
    }
}

- (CGRect)_descriptionLabelFrame {
    
    if (self.editing) {
        return CGRectMake(IMAGE_SIZE + EDITING_INSET + TEXT_LEFT_MARGIN, 22.0, self.contentView.bounds.size.width - IMAGE_SIZE - EDITING_INSET - TEXT_LEFT_MARGIN, 16.0);
    }
	else {
        return CGRectMake(IMAGE_SIZE + TEXT_LEFT_MARGIN, 22.0, self.contentView.bounds.size.width - IMAGE_SIZE - TEXT_LEFT_MARGIN, 16.0);
    }
}

- (CGRect)_prepTimeLabelFrame {
    
    CGRect contentViewBounds = self.contentView.bounds;
    return CGRectMake(contentViewBounds.size.width - PREP_TIME_WIDTH - TEXT_RIGHT_MARGIN, 4.0, PREP_TIME_WIDTH, 16.0);
}


#pragma mark - Recipe set accessor

- (void)setRecipe:(Recipe *)newRecipe {
    
    if (newRecipe != _recipe) {
        _recipe = newRecipe;
	}
	self.recipeImageView.image = _recipe.thumbnailImage;
	self.nameLabel.text = (_recipe.name.length > 0) ? _recipe.name : @"-";
	self.overviewLabel.text = (_recipe.overview != nil) ? _recipe.overview : @"-";
	self.prepTimeLabel.text = (_recipe.prepTime != nil) ? _recipe.prepTime : @"-";
}

@end
