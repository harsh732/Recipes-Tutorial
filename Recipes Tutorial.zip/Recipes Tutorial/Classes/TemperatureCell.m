

#import "TemperatureCell.h"

@implementation TemperatureCell

- (void)setTemperatureDataFromDictionary:(NSDictionary *)temperatureDictionary {
    
    // update text in labels from the dictionary
    self.cLabel.text = [temperatureDictionary objectForKey:@"c"];
    self.fLabel.text = [temperatureDictionary objectForKey:@"f"];
    self.gLabel.text = [temperatureDictionary objectForKey:@"g"];
}

@end
