
#import "TypeSelectionViewController.h"
#import "Recipe.h"

@interface TypeSelectionViewController()

@property (nonatomic, strong) NSArray *recipeTypes;

@end


#pragma mark -

@implementation TypeSelectionViewController

static NSString *MyIdentifier = @"MyIdentifier";

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
	self.title = @"Category";
    
    // right bar button item will dismiss this view controller
    self.navigationItem.rightBarButtonItem =
    [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone
                                                  target:self
                                                  action:@selector(doneAction:)];
    
    // fetch the recipe types in alphabetical order by name from the recipe's context
	NSManagedObjectContext *context = [self.recipe managedObjectContext];
	
	NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
	[fetchRequest setEntity:[NSEntityDescription entityForName:@"RecipeType" inManagedObjectContext:context]];
	NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"name" ascending:YES];
	NSArray *sortDescriptors = [[NSArray alloc] initWithObjects:&sortDescriptor count:1];
	[fetchRequest setSortDescriptors:sortDescriptors];
    NSArray *types = [context executeFetchRequest:fetchRequest error:nil];
	self.recipeTypes = types;
}

- (void)viewDidLoad {
    
    [super viewDidLoad];
     
    // register this class for our cell to this table view under the specified identifier 'MyIdentifier'
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:MyIdentifier];
}

- (IBAction)doneAction:(id)sender {
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    // Number of rows is the number of recipe types
    return self.recipeTypes.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:MyIdentifier forIndexPath:indexPath];
    
    // Configure the cell
	NSManagedObject *recipeType = [self.recipeTypes objectAtIndex:indexPath.row];
    cell.textLabel.text = [recipeType valueForKey:@"name"];
    
    if (recipeType == self.recipe.type) {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    }
    
    return cell;
}


#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	
    // If there was a previous selection, unset the accessory view for its cell.
	NSManagedObject *currentType = self.recipe.type;
	
    if (currentType != nil) {
		NSInteger index = [self.recipeTypes indexOfObject:currentType];
		NSIndexPath *selectionIndexPath = [NSIndexPath indexPathForRow:index inSection:0];
        UITableViewCell *checkedCell = [tableView cellForRowAtIndexPath:selectionIndexPath];
        checkedCell.accessoryType = UITableViewCellAccessoryNone;
    }

    // Set the checkmark accessory for the selected row.
    [[tableView cellForRowAtIndexPath:indexPath] setAccessoryType:UITableViewCellAccessoryCheckmark];    

     // Update the type of the recipe instance
    self.recipe.type = [self.recipeTypes objectAtIndex:indexPath.row];
    
    // Deselect the row.
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

@end
