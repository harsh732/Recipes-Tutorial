
@interface ImperialPickerController : NSObject

- (void)updateLabel;

@end
