

@interface MetricPickerController : NSObject

- (void)updateLabel;

@end
