

#import "InstructionsViewController.h"
#import "Recipe.h"

@interface InstructionsViewController ()

@property (nonatomic, strong) IBOutlet UITextView *instructionsText;
@property (nonatomic, strong) IBOutlet UILabel *nameLabel;

@end


#pragma mark -

@implementation InstructionsViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    self.navigationItem.title = @"Instructions";
    self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    // Update the views appropriately
    self.nameLabel.text = self.recipe.name;
    self.instructionsText.text = self.recipe.instructions;
}

- (void)setEditing:(BOOL)editing animated:(BOOL)animated {

    [super setEditing:editing animated:animated];

    self.instructionsText.editable = editing;
	[self.navigationItem setHidesBackButton:editing animated:YES];

	/*
	 If editing is finished, update the recipe's instructions and save the managed object context.
	 */
	if (!editing) {
		self.recipe.instructions = self.instructionsText.text;
		
		NSManagedObjectContext *context = self.recipe.managedObjectContext;
		NSError *error = nil;
		if (![context save:&error]) {
			
			NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
			abort();
		}
	}		
}

@end
