

@class Recipe;

@interface InstructionsViewController : UIViewController

@property (nonatomic, strong) Recipe *recipe;

@end
