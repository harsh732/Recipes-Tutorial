

#import "Recipe.h"

@interface RecipeTableViewCell : UITableViewCell

@property (nonatomic, strong) Recipe *recipe;

@end
