

@interface TemperatureCell : UITableViewCell

@property (nonatomic, strong) IBOutlet UILabel *cLabel;
@property (nonatomic, strong) IBOutlet UILabel *fLabel;
@property (nonatomic, strong) IBOutlet UILabel *gLabel;

- (void)setTemperatureDataFromDictionary:(NSDictionary *)temperatureDictionary;

@end
